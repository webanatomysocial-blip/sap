-- Database Schema for SAP Security Expert
-- Optimized for MySQL/MariaDB (cPanel Hosting)

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET FOREIGN_KEY_CHECKS = 0;
START TRANSACTION;
SET time_zone = "+00:00";

-- --------------------------------------------------------

-- Table structure for table `users` (For Admin Access)
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('admin','editor') DEFAULT 'editor',
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Table structure for table `blogs`
DROP TABLE IF EXISTS `blogs`;
CREATE TABLE `blogs` (
  `id` varchar(100) NOT NULL,
  `title` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `excerpt` text DEFAULT NULL,
  `content` longtext DEFAULT NULL,
  `author` varchar(100) DEFAULT 'Admin',
  `date` date DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `category` varchar(100) DEFAULT 'sap-security',
  `tags` varchar(255) DEFAULT NULL,
  `view_count` int(11) DEFAULT 0,
  `meta_title` varchar(255) DEFAULT NULL,
  `meta_description` text DEFAULT NULL,
  `status` enum('draft','published') DEFAULT 'published',
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`),
  KEY `idx_category` (`category`),
  KEY `idx_date` (`date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Table structure for table `comments`
DROP TABLE IF EXISTS `comments`;
CREATE TABLE `comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `post_id` varchar(100) NOT NULL,
  `user_name` varchar(100) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `content` text NOT NULL,
  `status` enum('pending','approved','rejected') DEFAULT 'pending',
  `timestamp` timestamp DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_post_id` (`post_id`),
  KEY `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Table structure for table `contributors`
DROP TABLE IF EXISTS `contributors`;
CREATE TABLE `contributors` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `full_name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `linkedin` varchar(255) DEFAULT NULL,
  `country` varchar(100) DEFAULT NULL,
  `organization` varchar(255) DEFAULT NULL,
  `designation` varchar(255) DEFAULT NULL,
  `role` varchar(255) DEFAULT NULL,
  `expertise` text DEFAULT NULL,
  `other_expertise` text DEFAULT NULL,
  `years_experience` varchar(50) DEFAULT NULL,
  `short_bio` text DEFAULT NULL,
  `contribution_types` text DEFAULT NULL,
  `proposed_topics` text DEFAULT NULL,
  `contributed_elsewhere` text DEFAULT NULL,
  `previous_work_links` text DEFAULT NULL,
  `preferred_frequency` varchar(100) DEFAULT NULL,
  `primary_motivation` text DEFAULT NULL,
  `weekly_time` varchar(50) DEFAULT NULL,
  `volunteer_events` text DEFAULT NULL,
  `product_evaluation` text DEFAULT NULL,
  `personal_website` varchar(255) DEFAULT NULL,
  `twitter_handle` varchar(255) DEFAULT NULL,
  `status` enum('pending','approved','rejected') DEFAULT 'pending',
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Table structure for table `analytics`
DROP TABLE IF EXISTS `analytics`;
CREATE TABLE `analytics` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `post_id` varchar(100) DEFAULT NULL,
  `ip_hash` varchar(64) DEFAULT NULL,
  `event_type` varchar(50) DEFAULT 'view',
  `path` varchar(255) DEFAULT NULL,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_post_id` (`post_id`),
  KEY `idx_created_at` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Table structure for table `announcements`
DROP TABLE IF EXISTS `announcements`;
CREATE TABLE `announcements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `date` date NOT NULL,
  `views` int(11) DEFAULT 0,
  `comments` int(11) DEFAULT 0,
  `link` varchar(255) DEFAULT NULL,
  `status` enum('active','inactive') DEFAULT 'active',
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Table structure for table `ads`
DROP TABLE IF EXISTS `ads`;
CREATE TABLE `ads` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `zone` varchar(100) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `link` varchar(255) DEFAULT NULL,
  `active` tinyint(1) DEFAULT 0,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `zone` (`zone`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Insert default admin (Change password immediately in cPanel phpMyAdmin!)
-- Default Credentials: admin / sap-security-2026
INSERT IGNORE INTO `users` (`username`, `password`, `role`) VALUES 
('admin', '$2y$12$dhXL13Y74enBjfq.DZGWAe.CAkgJ5UCCc1FLvPYbt7W5tTYj9vZi6', 'admin');

SET FOREIGN_KEY_CHECKS = 1;
COMMIT;
-- Real Blog Data
INSERT INTO `blogs` (`id`, `title`, `slug`, `excerpt`, `content`, `date`, `category`, `image`, `status`) VALUES
('grc-compliance-management-in-sap', 'GRC Compliance Management in SAP: Powering Enterprise-Wide Governance, Risk, and Compliance', 'grc-compliance-management-in-sap', 'Discover how a unified SAP GRC suite delivers continuous, enterprise-grade Governance, Risk, and Compliance.', '<p>Discover how a unified SAP GRC suite delivers continuous, enterprise-grade Governance, Risk, and Compliance.</p>', '2026-01-21', 'sap-grc', '/assets/blog-images/grc-compliance-management.jpg', 'published'),
('mastering-sap-grc-ruleset-manager', 'Mastering SAP GRC Ruleset Manager: A Complete Overview', 'mastering-sap-grc-ruleset-manager', 'Learn how the new Ruleset Manager in SAP GRC 12.0 SP25 transforms access risk governance.', '<p>Learn how the new Ruleset Manager in SAP GRC 12.0 SP25 transforms access risk governance.</p>', '2026-01-22', 'sap-grc', '/assets/blog-images/mastering-grc-ruleset.jpg', 'published'),
('integrating-okta-with-sap-ias-ips', 'Integrating Okta with SAP IAS/IPS — Step-by-Step IAM Best Practices', 'integrating-okta-with-sap-ias-ips', 'Practical guidance for establishing trust and identity federation between Okta and SAP cloud identity services.', '<p>Practical guidance for establishing trust and identity federation between Okta and SAP cloud identity services.</p>', '2026-01-23', 'sap-security', '/assets/blog-images/integrating-okta.jpg', 'published'),
('sap-public-cloud-authorisation-upgrade', 'SAP Public Cloud Authorisation Upgrade Guide', 'sap-public-cloud-authorisation-upgrade', 'A comprehensive guide to navigating quarterly IAM updates and release management in SAP Public Cloud.', '<p>A comprehensive guide to navigating quarterly IAM updates and release management in SAP Public Cloud.</p>', '2026-02-02', 'sap-public-cloud', '/assets/blog-images/public-cloud-auth-upgrade.jpg', 'published'),
('traditional-sap-audit-controls-fail-public-cloud', 'Why Traditional SAP Audit Controls Fail in Public Cloud', 'traditional-sap-audit-controls-fail-public-cloud', 'Understanding the shift from detective validation to preventive platform-level controls in the cloud.', '<p>Understanding the shift from detective validation to preventive platform-level controls in the cloud.</p>', '2026-01-25', 'sap-security', '/assets/blog-images/audit-controls-fail.jpg', 'published'),
('configuration-without-spro-sap-public-cloud', 'Configuration Without SPRO: The New Audit Reality', 'configuration-without-spro-sap-public-cloud', 'How Centralized Parameter Configuration (CPC) replaces SPRO for governance and risk reduction.', '<p>How Centralized Parameter Configuration (CPC) replaces SPRO for governance and risk reduction.</p>', '2026-01-26', 'sap-security', '/assets/blog-images/configuration-without-spro.jpg', 'published'),
('cpc-vs-spro-security-centric-view', 'CPC vs. SPRO: A Security-Centric View', 'cpc-vs-spro-security-centric-view', 'Comparing the security characteristics of traditional SPRO vs. modern CPC in SAP landscapes.', '<p>Comparing the security characteristics of traditional SPRO vs. modern CPC in SAP landscapes.</p>', '2026-01-27', 'sap-security', '/assets/blog-images/cpc-vs-spro.jpg', 'published'),
('sap-cybersecurity-insights-authors-podcast', 'SAP Cybersecurity Insights from the Authors', 'sap-cybersecurity-insights-authors-podcast', 'Episode highlights from the Cyber Kriya Podcast featuring the authors of Cybersecurity for SAP.', '<p>Episode highlights from the Cyber Kriya Podcast featuring the authors of Cybersecurity for SAP.</p>', '2026-01-28', 'sap-cybersecurity', '/assets/blog-images/cybersecurity-insights.jpg', 'published'),
('sap-licensing-optimization-false-savings', 'SAP Licensing Optimization vs. License Saver Tools', 'sap-licensing-optimization-false-savings', 'Why true optimization must be SAP-native and why \'license saver\' tools often increase audit liability.', '<p>Why true optimization must be SAP-native and why \'license saver\' tools often increase audit liability.</p>', '2026-01-24', 'sap-licensing', '/assets/blog-images/licensing-optimization.jpg', 'published'),
('what-actually-optimizes-sap-licenses', 'What Actually Optimizes SAP Licenses: STAR, USMM, LAW', 'what-actually-optimizes-sap-licenses', 'A layered look at collector, compliance, and intelligence tools in the SAP license ecosystem.', '<p>A layered look at collector, compliance, and intelligence tools in the SAP license ecosystem.</p>', '2026-01-29', 'sap-licensing', '/assets/blog-images/what-actually-optimizes.jpg', 'published'),
('magician-machine-sap-cybersecurity-podcast', 'The Magician, the Machine, and SAP Cybersecurity', 'magician-machine-sap-cybersecurity-podcast', 'Exploring the evolution of SAP threats and Agentic AI risk with Jay Thoden van Velzen.', '<p>Exploring the evolution of SAP threats and Agentic AI risk with Jay Thoden van Velzen.</p>', '2026-01-30', 'sap-cybersecurity', '/assets/blog-images/magician-and-machine.jpg', 'published'),
('public-vs-private-cloud-security-comparison', 'S/4HANA Public Cloud vs. Private Cloud: Security Perspective', 'public-vs-private-cloud-security-comparison', 'Deciding between GROW and RISE paths based on control boundaries and audit requirements.', '<p>Deciding between GROW and RISE paths based on control boundaries and audit requirements.</p>', '2026-02-01', 'sap-security', '/assets/blog-images/public-vs-private-cloud.jpg', 'published'),
('regained-sap-security-expert', 'Regained SAP Security Expert!', 'regained-sap-security-expert', 'The platform is back. Reclaiming the space for SAP Security and GRC knowledge sharing.', '<p>The platform is back. Reclaiming the space for SAP Security and GRC knowledge sharing.</p>', '2026-01-05', 'sap-grc', '/assets/blog-images/regained-sap-security-expert.jpg', 'published');
SET FOREIGN_KEY_CHECKS = 1;
COMMIT;
